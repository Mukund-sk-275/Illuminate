import SwiftUI

// A single log entry containing the user's text and the date it was created.
struct LogEntry: Identifiable {
    let id = UUID()
    let text: String
    let date: Date
}

// Observable object storing all log entries and grouping logic.
class LogHistoryViewModel: ObservableObject {
    @Published var logs: [LogEntry] = []
    
    /// Adds a new log to the array with the current date/time.
    func addLog(_ text: String) {
        let newLog = LogEntry(text: text, date: Date())
        logs.append(newLog)
    }
    
    /// Returns logs grouped by the time difference from now.
    var groupedLogs: [String: [LogEntry]] {
        var result: [String: [LogEntry]] = [
            "Today": [],
            "Yesterday": [],
            "This Week": [],
            "Last Week": []
        ]
        
        for log in logs {
            let category = timeCategory(for: log.date)
            result[category]?.append(log)
        }
        
        return result
    }
    
    /// Determines which date category a log belongs to.
    private func timeCategory(for date: Date) -> String {
        let calendar = Calendar.current
        let now = Date()
        guard let dayDifference = calendar.dateComponents([.day], from: date, to: now).day else {
            return "Last Week"
        }
        
        switch dayDifference {
        case 0: return "Today"
        case 1: return "Yesterday"
        case 2..<7: return "This Week"
        default: return "Last Week"
        }
    }
}

struct LogHistoryAndInsightsView: View {
    @EnvironmentObject var logs: LogHistoryViewModel
    
    // Fixed order for displaying categories.
    let categories = ["Today", "Yesterday", "This Week", "Last Week"]
    
    var body: some View {
        Group {
            if logs.logs.isEmpty {
                VStack {
                    Spacer()
                    Text("Log at least one thought.")
                        .font(.title3)
                        .foregroundColor(.gray)
                    Spacer()
                }
                .navigationTitle("Log History & Insights")
            } else {
                List {
                    ForEach(categories, id: \.self) { category in
                        if let entries = logs.groupedLogs[category], !entries.isEmpty {
                            Section(header: Text(category).font(.headline)) {
                                ForEach(entries) { entry in
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(entry.text)
                                            .font(.body)
                                        Text(formattedDate(entry.date))
                                            .font(.caption)
                                            .foregroundColor(.gray)
                                    }
                                    .padding(.vertical, 4)
                                }
                            }
                        }
                    }
                }
                .listStyle(InsetGroupedListStyle())
                .navigationTitle("Log History & Insights")
            }
        }
    }
    
    /// Formats date & time for display in each log entry.
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

struct LogHistoryAndInsightsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            LogHistoryAndInsightsView()
                .environmentObject(LogHistoryViewModel())
        }
    }
}
