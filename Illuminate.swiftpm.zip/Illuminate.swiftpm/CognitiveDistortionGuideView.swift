import SwiftUI

// Data Model for a Cognitive Distortion / Negative Thought Pattern (includes multiple alternative suggestions)
struct CognitiveDistortion: Identifiable, Codable {
    let id = UUID()
    let name: String
    let description: String
    let keywords: [String]
    let alternatives: [String]
}

// Global sample database for cognitive distortions with alternatives
let cognitiveDistortions: [CognitiveDistortion] = [
    CognitiveDistortion(
        name: "Overgeneralization",
        description: "Generalizing one event to a pattern.",
        keywords: ["always", "never", "every", "everyone", "all", "nothing"],
        alternatives: [
            "List evidence for and against your thought.",
            "Reflect on the uniqueness of this situation.",
            "Focus on specific instances, not patterns.",
            "Challenge the thought with facts."
        ]
    ),
    CognitiveDistortion(
        name: "Catastrophizing",
        description: "Expecting worst-case scenarios.",
        keywords: ["disaster", "catastrophe", "worst", "ruined", "nightmare", "horrible"],
        alternatives: [
            "Visualize a realistic, positive outcome.",
            "Break the situation into manageable parts.",
            "Recall times when things improved.",
            "Practice deep breathing or a calming activity."
        ]
    ),
    CognitiveDistortion(
        name: "Black-and-White Thinking",
        description: "Seeing things as all good or all bad.",
        keywords: ["completely", "totally", "entirely", "all", "nothing"],
        alternatives: [
            "Look for gray areas in your situation.",
            "Acknowledge both strengths and weaknesses.",
            "Seek a balanced, middle ground.",
            "Consider that most things are not absolute."
        ]
    ),
    CognitiveDistortion(
        name: "Personalization",
        description: "Taking undue blame for events.",
        keywords: ["my fault", "blame", "responsible", "guilty"],
        alternatives: [
            "Consider external factors influencing the event.",
            "Remember not all responsibility is yours.",
            "Discuss your thoughts with someone you trust.",
            "Reflect on what was beyond your control."
        ]
    ),
    CognitiveDistortion(
        name: "Filtering",
        description: "Focusing solely on negatives.",
        keywords: ["only", "ignore", "disregard", "neglect"],
        alternatives: [
            "List positive aspects along with negatives.",
            "Practice gratitude by noting small wins.",
            "Challenge your view with positive memories.",
            "Reframe your focus to see the whole picture."
        ]
    ),
    CognitiveDistortion(
        name: "Should Statements",
        description: "Imposing rigid expectations.",
        keywords: ["should", "must", "ought", "have to"],
        alternatives: [
            "Replace 'should' with 'could' or 'might'.",
            "Set realistic, flexible goals.",
            "Practice self-compassion.",
            "Turn 'should' into a constructive suggestion."
        ]
    ),
    CognitiveDistortion(
        name: "Labeling",
        description: "Assigning a fixed negative label.",
        keywords: ["stupid", "failure", "loser", "worthless", "useless"],
        alternatives: [
            "Recognize your multiple strengths.",
            "Replace harsh labels with specific behaviors.",
            "Acknowledge your achievements.",
            "Focus on growth rather than negative labels."
        ]
    ),
    CognitiveDistortion(
        name: "Mind Reading",
        description: "Assuming negative thoughts about others.",
        keywords: ["think", "assume", "suppose", "believe"],
        alternatives: [
            "Ask for clarity instead of assuming.",
            "Consider other possible explanations.",
            "Remember you may not know their thoughts.",
            "Focus on observable facts."
        ]
    ),
    CognitiveDistortion(
        name: "Emotional Reasoning",
        description: "Believing feelings are facts.",
        keywords: ["feel", "feeling", "emotion", "emotional"],
        alternatives: [
            "Remember feelings can mislead.",
            "Challenge emotions with evidence.",
            "Separate your feelings from facts.",
            "Practice mindfulness to observe emotions."
        ]
    ),
    CognitiveDistortion(
        name: "Discounting the Positive",
        description: "Ignoring positive experiences.",
        keywords: ["ignore", "discount", "minimize", "doesn't count"],
        alternatives: [
            "List three positive things from today.",
            "Celebrate even small successes.",
            "Reflect on your accomplishments.",
            "Ask someone for positive feedback."
        ]
    ),
    CognitiveDistortion(
        name: "Magnification & Minimization",
        description: "Exaggerating negatives and downplaying positives.",
        keywords: ["exaggerate", "blow up", "downplay", "minimize"],
        alternatives: [
            "List both pros and cons equally.",
            "Assess the situation realistically.",
            "Focus on factual details.",
            "Seek a friend’s perspective for balance."
        ]
    ),
    CognitiveDistortion(
        name: "Jumping to Conclusions",
        description: "Making hasty assumptions without enough evidence.",
        keywords: ["assume", "conclude", "infer", "predict", "expect"],
        alternatives: [
            "Wait for more information.",
            "Challenge your assumptions with questions.",
            "Consider alternative outcomes.",
            "Reflect if your conclusion is based on facts."
        ]
    ),
    CognitiveDistortion(
        name: "Rumination",
        description: "Obsessively dwelling on negatives.",
        keywords: ["ruminate", "dwelling", "obsess", "stuck"],
        alternatives: [
            "Distract yourself with a hobby.",
            "Practice mindfulness and let thoughts pass.",
            "Set a time limit for reflection.",
            "Focus on a productive activity."
        ]
    ),
    CognitiveDistortion(
        name: "Hopelessness",
        description: "Believing nothing will improve.",
        keywords: ["hopeless", "despair", "no hope", "can't change"],
        alternatives: [
            "Recall a past success.",
            "Set a small, achievable goal.",
            "Talk to someone supportive.",
            "Plan a small change to boost hope."
        ]
    ),
    CognitiveDistortion(
        name: "Self-Criticism",
        description: "Harshly judging yourself.",
        keywords: ["self-criticism", "inadequate", "failure", "flawed", "inferior"],
        alternatives: [
            "List your positive qualities.",
            "Remember everyone makes mistakes.",
            "Practice self-compassion.",
            "Focus on your progress."
        ]
    )
]

struct CognitiveDistortionGuideView: View {
    var body: some View {
        NavigationView {
            List(cognitiveDistortions) { distortion in
                NavigationLink(destination: CognitiveDistortionDetailView(distortion: distortion)) {
                    VStack(alignment: .leading) {
                        Text(distortion.name)
                            .font(.body)
                        Text("Keywords: \(distortion.keywords.joined(separator: ", "))")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Cognitive Distortions")
        }
    }
}

struct CognitiveDistortionDetailView: View {
    let distortion: CognitiveDistortion
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(distortion.name)
                    .font(.largeTitle)
                    .bold()
                Text(distortion.description)
                    .font(.body)
                Text("Alternative Suggestions:")
                    .font(.headline)
                    .foregroundColor(.green)
                ForEach(distortion.alternatives, id: \.self) { alternative in
                    Text("• \(alternative)")
                        .font(.body)
                }
                Text("Keywords: \(distortion.keywords.joined(separator: ", "))")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding()
        }
        .navigationTitle(distortion.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct CognitiveDistortionGuideView_Previews: PreviewProvider {
    static var previews: some View {
        CognitiveDistortionGuideView()
    }
}
