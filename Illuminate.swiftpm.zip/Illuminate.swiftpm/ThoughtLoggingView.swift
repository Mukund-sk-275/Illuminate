import SwiftUI

struct ThoughtLoggingView: View {
    @EnvironmentObject var logs: LogHistoryViewModel  // Shared log model
    @State private var userThought: String = ""
    @State private var analysisResult: String = ""
    @State private var alternativeResult: String = ""
    // Load distortions from the global sample database
    @State private var distortions: [CognitiveDistortion] = cognitiveDistortions

    var body: some View {
        Form {
            // Section for entering a negative thought
            Section(header: Text("Your Negative Thought")) {
                TextEditor(text: $userThought)
                    .frame(minHeight: 100)
                    .onChange(of: userThought) { newValue in
                        analyzeThought(newValue)
                    }
            }
            
            // Section to display the detected cognitive distortion
            Section(header: Text("Detected Cognitive Distortion")) {
                Text(analysisResult.isEmpty ? "No analysis yet." : analysisResult)
                    .foregroundColor(.blue)
            }
            
            // Section to display a randomly selected alternative suggestion
            Section(header: Text("Alternative Suggestion")) {
                Text(alternativeResult.isEmpty ? "No alternative available." : alternativeResult)
                    .foregroundColor(.green)
            }
            
            // Section with an Add button to save the thought to Log History
            Section {
                Button(action: {
                    logs.addLog(userThought) // Save the thought to shared model
                    userThought = ""
                    analysisResult = ""
                    alternativeResult = ""
                }) {
                    HStack {
                        Spacer()
                        Text("Add")
                            .font(.headline)
                            .foregroundColor(.white)
                        Spacer()
                    }
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(8)
                }
            }
        }
        .navigationTitle("Thought Logging")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    // MARK: - Levenshtein Distance Implementation
    func levenshteinDistance(_ s1: String, _ s2: String) -> Int {
        let empty = [Int](repeating: 0, count: s2.count + 1)
        var last = [Int](0...s2.count)
        for (i, c1) in s1.enumerated() {
            var cur = [i + 1] + empty
            for (j, c2) in s2.enumerated() {
                cur[j + 1] = c1 == c2 ? last[j] : min(last[j], last[j + 1], cur[j]) + 1
            }
            last = cur
        }
        return last.last!
    }
    
    // MARK: - Analysis Function Using Weighted Fuzzy Matching with Alternatives
    private func analyzeThought(_ thought: String) {
        let lowerThought = thought.lowercased()
        let words = lowerThought.split(separator: " ").map { String($0) }
        var bestMatch: CognitiveDistortion?
        var highestScore: Double = 0
        
        // Iterate over each distortion in the reference database
        for distortion in distortions {
            var score: Double = 0
            for keyword in distortion.keywords {
                for word in words {
                    let distance = Double(levenshteinDistance(word, keyword))
                    // Tighter threshold using /4 instead of /3
                    let threshold = Double(max(1, keyword.count / 4))
                    if distance == 0 {
                        // Strong bonus for exact match
                        score += 10
                    } else if distance <= threshold {
                        score += (Double(keyword.count) - distance)
                    }
                }
            }
            if score > highestScore {
                highestScore = score
                bestMatch = distortion
            }
        }
        
        if let best = bestMatch, highestScore > 0 {
            analysisResult = "\(best.name): \(best.description)"
            alternativeResult = best.alternatives.randomElement() ?? ""
        } else {
            analysisResult = "No clear cognitive distortion detected. Please reflect further."
            alternativeResult = ""
        }
    }
}

struct ThoughtLoggingView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ThoughtLoggingView()
                .environmentObject(LogHistoryViewModel())
        }
    }
}
