import Foundation

// Renamed to avoid redeclaration conflicts.
struct CognitiveDistortionModel: Identifiable, Codable {
    var id = UUID()
    let name: String
    let description: String
    let keywords: [String]
}

func loadCognitiveDistortions() -> [CognitiveDistortionModel] {
    guard let url = Bundle.main.url(forResource: "CognitiveDistortions", withExtension: "json"),
          let data = try? Data(contentsOf: url) else {
        print("Failed to locate or load CognitiveDistortions.json")
        return []
    }
    do {
        let distortions = try JSONDecoder().decode([CognitiveDistortionModel].self, from: data)
        return distortions
    } catch {
        print("Error decoding JSON: \(error)")
        return []
    }
}
