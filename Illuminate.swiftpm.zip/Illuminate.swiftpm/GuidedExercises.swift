import SwiftUI

// MARK: - Guided Reframing Exercises Navigation Screen
struct GuidedReframingExercisesView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: FourSevenEightBreathingView()) {
                    Text("4-7-8 Breathing")
                        .font(.headline)
                }
                // Additional guided exercises can be added here.
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Guided Reframing Exercises")
        }
    }
}

// MARK: - 4-7-8 Breathing Exercise Screen
struct FourSevenEightBreathingView: View {
    @State private var isRunning: Bool = false
    @State private var scale: CGFloat = 1.0
    @State private var currentPhase: String = ""
    @State private var cycleCount: Int = 0
    @State private var currentCycleProgress: Double = 0.0
    private let totalCycles: Int = 4
    
    var body: some View {
        VStack(spacing: 40) {
            // Animated red circle for breathing animation
            Circle()
                .fill(Color.red.opacity(0.3))
                .frame(width: 150, height: 150)
                .scaleEffect(scale)
            
            // Display current phase: "Inhale", "Hold", or "Exhale"
            Text(currentPhase)
                .font(.title)
                .bold()
            
            // Custom segmented progress bar for 4 cycles
            CycleProgressBar(cycleCount: cycleCount, currentCycleProgress: currentCycleProgress, totalCycles: totalCycles)
                .padding(.horizontal)
            
            // Start/Restart button shown when not running
            if !isRunning {
                Button(action: startExercise) {
                    Text(cycleCount == totalCycles ? "Start Again" : "Start")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }
            }
        }
        .padding()
        .navigationTitle("4-7-8 Breathing")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    // Helper function to animate phase progress in small steps
    func animatePhase(duration: UInt64, update: @escaping (Double) -> Void) async {
        let steps = Int(duration / 100_000_000) // updates every 0.1 sec
        for step in 1...steps {
            try? await Task.sleep(nanoseconds: 100_000_000)
            update(Double(step) / Double(steps))
        }
    }
    
    func startExercise() {
        isRunning = true
        cycleCount = 0
        currentCycleProgress = 0.0
        Task {
            for _ in 1...totalCycles {
                // Inhale phase: scale up over 4 seconds
                currentPhase = "Inhale"
                withAnimation(.linear(duration: 4)) {
                    scale = 1.5
                }
                await animatePhase(duration: 4_000_000_000) { phaseProgress in
                    currentCycleProgress = phaseProgress * (4.0 / 19.0)
                }
                
                // Hold phase: maintain scale for 7 seconds
                currentPhase = "Hold"
                await animatePhase(duration: 7_000_000_000) { phaseProgress in
                    currentCycleProgress = (4.0 / 19.0) + phaseProgress * (7.0 / 19.0)
                }
                
                // Exhale phase: scale down over 8 seconds
                currentPhase = "Exhale"
                withAnimation(.linear(duration: 8)) {
                    scale = 1.0
                }
                await animatePhase(duration: 8_000_000_000) { phaseProgress in
                    currentCycleProgress = ((4.0 + 7.0) / 19.0) + phaseProgress * (8.0 / 19.0)
                }
                
                cycleCount += 1
                currentCycleProgress = 1.0
            }
            // Reset state after completing all cycles
            isRunning = false
            currentPhase = ""
            currentCycleProgress = 0.0
        }
    }
}

// Custom segmented progress bar view
struct CycleProgressBar: View {
    var cycleCount: Int
    var currentCycleProgress: Double
    var totalCycles: Int
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<totalCycles, id: \.self) { index in
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Rectangle().foregroundColor(Color.gray.opacity(0.3))
                        Rectangle().foregroundColor(Color.red)
                            .frame(width: fillWidth(for: index, totalWidth: geo.size.width))
                    }
                }
                .frame(height: 8)
            }
        }
    }
    
    func fillWidth(for index: Int, totalWidth: CGFloat) -> CGFloat {
        if index < cycleCount {
            return totalWidth
        } else if index == cycleCount {
            return CGFloat(currentCycleProgress) * totalWidth
        } else {
            return 0
        }
    }
}

// Preview for testing the navigation and exercise screen
struct GuidedReframingExercisesView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            GuidedReframingExercisesView()
        }
    }
}
