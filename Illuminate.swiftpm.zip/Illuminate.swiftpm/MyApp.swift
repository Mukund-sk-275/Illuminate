import SwiftUI

// Assume LogHistoryViewModel is defined elsewhere (or include its definition in its own file)
@main
struct MyApp: App {
    @StateObject var logs = LogHistoryViewModel()
    
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(logs) // Inject the shared model
        }
    }
}
