import SwiftUI

// MARK: - Main Home Screen
struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                // THOUGHT & REFLECTION Section
                Section(header: Text("THOUGHT & REFLECTION")
                            .font(.caption)
                            .foregroundColor(.gray)) {
                    NavigationLink(destination: ThoughtLoggingView()) {
                        Label("Thought Logging", systemImage: "doc.text")
                    }
                    NavigationLink(destination: LogHistoryAndInsightsView()) {
                        Label("Log History and Insights", systemImage: "magnifyingglass.circle")
                    }
                }
                
                // COGNITIVE SUPPORT TOOLS Section
                Section(header: Text("COGNITIVE SUPPORT TOOLS")
                            .font(.caption)
                            .foregroundColor(.gray)) {
                    NavigationLink(destination: CognitiveDistortionGuideView()) {
                        Label("Cognitive Distortion Reference Guide", systemImage: "triangle.circle")
                    }
                }
                
                // MOOD & REFRAMING Section
                Section(header: Text("MOOD & REFRAMING")
                            .font(.caption)
                            .foregroundColor(.gray)) {
                    NavigationLink(destination: Text("Mood Tracker Insights")) {
                        Label("Mood Tracker Insights", systemImage: "bolt.shield")
                    }
                    NavigationLink(destination: GuidedReframingExercisesView()) {
                        Label("Guided Reframing Exercises", systemImage: "info.circle")
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Illuminate")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        // Profile action here
                    }) {
                        Image(systemName: "person.circle")
                            .font(.title2)
                    }
                }
            }
        }
    }
}

// MARK: - Tab Bar & Settings
struct MainTabView: View {
    var body: some View {
        TabView {
            ContentView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
        }
    }
}

struct SettingsView: View {
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("APP SETTINGS")
                            .font(.caption)
                            .foregroundColor(.gray)) {
                    NavigationLink(destination: Text("Notifications")) {
                        Label("Notifications", systemImage: "bell")
                    }
                    NavigationLink(destination: Text("About Us")) {
                        Label("About Us", systemImage: "info.circle")
                    }
                    NavigationLink(destination: Text("Privacy")) {
                        Label("Privacy", systemImage: "lock.shield")
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Settings")
        }
    }
}

struct HomeContentView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
    }
}
